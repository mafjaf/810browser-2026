#!/bin/bash
# 実行している場所のディレクトリに移動
cd "$(dirname "$0")"

echo "--- 810浄化機 起動 ---"

# 同じフォルダ内にある .app をすべて浄化
for app in *.app; do
    if [ -d "$app" ]; then
        echo "浄化中: $app"
        xattr -cr "$app"
    fi
done

echo "----------------------"
echo "浄化が完了しました。このウィンドウを閉じても大丈夫です。"
# 勝手に閉じないように入力を待つ
read
